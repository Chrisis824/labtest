# CSS-Tutorial-lab03

This is a basic example of pure CSS tab navigation (i.e. no Javascript), with a basic CSS animation for you to experiment with.

However, although the `:target` method works it is not ideal, so the recommendation is to use the radio button `:checked` method you'll find in the online tutorials for the second exercise.
